package cv1;
public class Cv1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(" Name: Bahram");
        System.out.println("Father Name: Arif Jafari");
        System.out.println("Age: 18");
        System.out.println("phone num: +93 766 709 301");
        System.out.println("Email Add: baramjafari2006@gmail.com");
        System.out.println("Address: Kabul, 13th District, Dashti-e-Barchi, Poly Khoshk");
        System.out.println("Languages: Dari, English, Pashto, Turkish");
        System.out.println("Favorite Sport: Football");
         System.out.println("Language Certificate: Duolingo English Test");
         System.out.println("Computer Skills: Office Packages, Photoshop, Design");
         System.out.println("Word per Minute: 32 words");
    }
    
}
